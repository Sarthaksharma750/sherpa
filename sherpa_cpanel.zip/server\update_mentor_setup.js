const mongoose = require('mongoose');
require('dotenv').config();
const FormConfig = require('./models/FormConfig');

async function run() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to DB');

    const updated = await FormConfig.findOneAndUpdate(
      { _id: 'mentor_setup' },
      {
        schema: {
          pages: [
            {
              id: 'page_1',
              title: 'Your UPSC experience',
              description: 'Tell us about your UPSC Civil Services Examination attempts and the stages you cleared.',
              questions: [
                { id: 'upscExperience', type: 'custom_upsc_experience', label: '' }
              ]
            },
            {
              id: 'page_2',
              title: 'About You',
              questions: [
                { id: 'bio', type: 'textarea', label: 'About Me (Bio)' },
                { id: 'city', type: 'address', label: 'City' },
                { id: 'linkedin', type: 'text', label: 'LinkedIn URL' },
                { id: 'education', type: 'institute', label: 'Education / Institution' },
                { id: 'organizations', type: 'text', label: 'Current/Past Organizations' },
                { id: 'hasMentored', type: 'dropdown', label: 'Have you guided students before?', options: ['Yes', 'No'] },
                { id: 'mentoringDuration', type: 'text', label: 'Duration of Mentoring Experience (e.g. 2 years)' },
                { id: 'video', type: 'file', label: 'Introductory Video (Optional)' }
              ]
            },
            {
              id: 'page_3',
              title: 'Best Attempts Details',
              questions: [
                { id: 'bestPrelimsYear', type: 'text', label: 'Best Prelims Attempt Year' },
                { id: 'bestMainsYear', type: 'text', label: 'Best Mains Attempt Year' },
                { id: 'bestInterviewYear', type: 'text', label: 'Best Interview Attempt Year' }
              ]
            },
            {
              id: 'page_4',
              title: 'How You Can Help',
              questions: [
                { id: 'studentTypes', type: 'multiselect', label: 'Student types you can guide', options: ['Starting UPSC', 'Mains Answer Writing', 'Working Professional', 'Interview Candidate'] },
                { id: 'helpAreas', type: 'multiselect', label: 'Help areas', options: ['Study Planning', 'Books & Resources', 'Mains Answer Writing', 'Essay Writing', 'Ethics (GS4)', 'Optional Subject', 'Interview Prep'] },
                { id: 'preparedWorking', type: 'dropdown', label: 'Did you prepare while working?', options: ['Yes', 'No'] },
                { id: 'optionalSubject', type: 'text', label: 'Optional Subject' }
              ]
            }
          ]
        }
      },
      { new: true, upsert: true }
    );
    console.log('Successfully updated mentor_setup config:', updated._id);
  } catch (err) {
    console.error('Migration failed:', err);
  } finally {
    mongoose.connection.close();
  }
}

run();
