const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const messageSchema = new mongoose.Schema({
  _id: String,
  conversationId: { type: String, required: true },
  senderId: { type: String, required: true },
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now, expires: 2592000 }
}, { _id: false });
messageSchema.plugin(transformPlugin);
module.exports = mongoose.model('Message', messageSchema);