const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const dayScheduleSchema = new mongoose.Schema({
  day: String,
  active: Boolean,
  start: String,
  end: String,
  slots: [{ start: String, end: String }]
}, { _id: false });

const mentorScheduleSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  week: [dayScheduleSchema],
  month: { type: Map, of: new mongoose.Schema({ start: String, end: String, unavailable: Boolean, slots: [{ start: String, end: String }] }, { _id: false }) }
}, { _id: false });
mentorScheduleSchema.plugin(transformPlugin);
module.exports = mongoose.model('MentorSchedule', mentorScheduleSchema, 'mentors_schedule');