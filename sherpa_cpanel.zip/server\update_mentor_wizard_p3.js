const mongoose = require('mongoose');
require('dotenv').config();
const FormConfig = require('./models/FormConfig');

async function run() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to DB');

    const config = await FormConfig.findById('mentor_setup');
    if (config) {
      // Keep up to page 2, and then push page 3
      let pages = config.schema.pages.slice(0, 2);
      pages.push({
        id: 'page_3',
        title: 'Mentor Dashboard',
        questions: [
          { id: 'dashboardHub', type: 'custom_dashboard', label: '' }
        ]
      });
      config.schema.pages = pages;
      config.markModified('schema.pages');
      await config.save();
      console.log('Successfully updated mentor_setup config to 3 pages');
    } else {
      console.log('mentor_setup config not found');
    }
  } catch (error) {
    console.error('Migration failed', error);
  } finally {
    mongoose.connection.close();
  }
}

run();
