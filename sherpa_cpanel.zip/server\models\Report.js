const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const reportSchema = new mongoose.Schema({
  _id: String,
  bookingId: { type: String, required: true },
  reporterId: { type: String, required: true },
  issueType: { type: String, required: true },
  description: { type: String, required: true },
  status: { type: String, default: 'pending' },
  adminReply: { type: String, default: '' },
  createdAt: { type: Date, default: Date.now }
}, { _id: false });

reportSchema.plugin(transformPlugin);

module.exports = mongoose.model('Report', reportSchema);
