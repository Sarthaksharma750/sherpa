const nodemailer = require('nodemailer');
const mongoose = require('mongoose');

const getTransporter = async () => {
  const Setting = mongoose.models['Setting'];
  if (!Setting) throw new Error('Setting model not found');
  
  const settings = await Setting.findOne({ _id: 'site_settings' });
  if (!settings || !settings.smtpServer || !settings.smtpUser || !settings.smtpPass) {
    throw new Error('SMTP settings are not configured on the server.');
  }

  return {
    transporter: nodemailer.createTransport({
      host: settings.smtpServer,
      port: parseInt(settings.smtpPort, 10) || 465,
      secure: true,
      auth: {
        user: settings.smtpUser,
        pass: settings.smtpPass,
      },
    }),
    senderEmail: settings.smtpUser,
    websiteName: settings.websiteName || 'Sherpa'
  };
};

const baseEmailTemplate = (title, content, buttonText, buttonLink, websiteName) => `
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body { margin: 0; padding: 0; font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; background-color: #f4f7f6; color: #1e293b; }
  .container { max-w-xl; margin: 40px auto; background-color: #ffffff; border-radius: 24px; overflow: hidden; box-shadow: 0 10px 25px rgba(0,0,0,0.05); }
  .header { background: linear-gradient(135deg, #215A9C 0%, #1e3a8a 100%); padding: 40px 20px; text-align: center; }
  .header h1 { color: #ffffff; margin: 0; font-size: 28px; font-weight: 800; letter-spacing: -0.5px; }
  .content { padding: 40px; }
  .title { font-size: 22px; font-weight: 700; color: #0f172a; margin-top: 0; margin-bottom: 20px; }
  .text { font-size: 16px; line-height: 1.6; color: #475569; margin-bottom: 24px; }
  .button-container { text-align: center; margin-top: 32px; margin-bottom: 10px; }
  .button { display: inline-block; background-color: #ea580c; color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 12px; font-weight: 600; font-size: 16px; box-shadow: 0 4px 14px rgba(234, 88, 12, 0.3); transition: transform 0.2s; }
  .footer { background-color: #f8fafc; padding: 24px; text-align: center; font-size: 14px; color: #94a3b8; border-top: 1px solid #e2e8f0; }
</style>
</head>
<body>
  <div class="container">
    <div class="header">
      <h1>${websiteName}</h1>
    </div>
    <div class="content">
      <h2 class="title">${title}</h2>
      ${content}
      ${buttonText ? `
      <div class="button-container">
        <a href="${buttonLink}" class="button">${buttonText}</a>
      </div>
      ` : ''}
    </div>
    <div class="footer">
      &copy; ${new Date().getFullYear()} ${websiteName}. All rights reserved.
    </div>
  </div>
</body>
</html>
`;

const sendSessionRequestEmail = async (mentorEmail, mentorName, aspirantName, date, time, duration, origin) => {
  try {
    const { transporter, senderEmail, websiteName } = await getTransporter();
    
    const content = `
      <p class="text">Hi <strong>${mentorName}</strong>,</p>
      <p class="text">You have a new mentorship session request from <strong>${aspirantName}</strong>.</p>
      <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 24px;">
        <p style="margin: 0 0 10px 0; font-size: 15px; color: #475569;"><strong>Date:</strong> ${date}</p>
        <p style="margin: 0 0 10px 0; font-size: 15px; color: #475569;"><strong>Time:</strong> ${time}</p>
        <p style="margin: 0; font-size: 15px; color: #475569;"><strong>Duration:</strong> ${duration} minutes</p>
      </div>
      <p class="text">Please log in to your dashboard to review and accept the request.</p>
    `;
    
    await transporter.sendMail({
      from: `"${websiteName}" <${senderEmail}>`,
      to: mentorEmail,
      subject: `New Session Request from ${aspirantName}`,
      html: baseEmailTemplate('New Session Request', content, 'View Session Details', `${origin}/sessions`, websiteName)
    });
  } catch (err) {
    console.error('Failed to send session request email:', err);
  }
};

const sendSessionAcceptedEmail = async (aspirantEmail, aspirantName, mentorName, date, time, origin) => {
  try {
    const { transporter, senderEmail, websiteName } = await getTransporter();
    
    const content = `
      <p class="text">Hi <strong>${aspirantName}</strong>,</p>
      <p class="text">Great news! <strong>${mentorName}</strong> has accepted your mentorship session request.</p>
      <div style="background: #f8fafc; padding: 20px; border-radius: 12px; border: 1px solid #e2e8f0; margin-bottom: 24px;">
        <p style="margin: 0 0 10px 0; font-size: 15px; color: #475569;"><strong>Date:</strong> ${date}</p>
        <p style="margin: 0; font-size: 15px; color: #475569;"><strong>Time:</strong> ${time}</p>
      </div>
      <p class="text">You can view the session details and join the meeting from your dashboard at the scheduled time.</p>
    `;
    
    await transporter.sendMail({
      from: `"${websiteName}" <${senderEmail}>`,
      to: aspirantEmail,
      subject: `Session Accepted by ${mentorName}`,
      html: baseEmailTemplate('Session Accepted! 🎉', content, 'View Session Details', `${origin}/sessions`, websiteName)
    });
  } catch (err) {
    console.error('Failed to send session accepted email:', err);
  }
};

const sendChatMessageEmail = async (receiverEmail, receiverName, senderName, messageText, senderId, origin) => {
  try {
    const { transporter, senderEmail, websiteName } = await getTransporter();
    
    const content = `
      <p class="text">Hi <strong>${receiverName}</strong>,</p>
      <p class="text">You have a new message from <strong>${senderName}</strong>:</p>
      <div style="background: #f0f9ff; padding: 20px; border-radius: 16px 16px 16px 4px; border: 1px solid #bae6fd; margin-bottom: 24px;">
        <p style="margin: 0; font-size: 16px; color: #0369a1; font-style: italic;">"${messageText}"</p>
      </div>
      <p class="text">Click the button below to reply directly in the chat.</p>
    `;
    
    await transporter.sendMail({
      from: `"${websiteName}" <${senderEmail}>`,
      to: receiverEmail,
      subject: `New Message from ${senderName}`,
      html: baseEmailTemplate('New Chat Message', content, 'Reply to Message', `${origin}/chats?userId=${senderId}`, websiteName)
    });
  } catch (err) {
    console.error('Failed to send chat message email:', err);
  }
};

module.exports = {
  sendSessionRequestEmail,
  sendSessionAcceptedEmail,
  sendChatMessageEmail
};
