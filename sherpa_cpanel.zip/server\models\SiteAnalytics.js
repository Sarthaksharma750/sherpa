const mongoose = require('mongoose');

const siteAnalyticsSchema = new mongoose.Schema({
  _id: { type: String, default: 'global_stats' },
  totalViews: { type: Number, default: 0 },
  uniqueViews: { type: Number, default: 0 },
  uniqueVisitors: { type: [String], default: [] } // Store IPs or simple token hashes
}, { timestamps: true });

const transformPlugin = require('./plugins/transform');
siteAnalyticsSchema.plugin(transformPlugin);

module.exports = mongoose.model('SiteAnalytics', siteAnalyticsSchema);
