const mongoose = require('mongoose');
require('dotenv').config();

mongoose.connect(process.env.MONGO_URI).then(async () => {
  const db = mongoose.connection.db;
  const config = await db.collection('formconfigs').findOne({_id: 'mentor_setup'});
  config.schema.pages.forEach(p => {
    p.questions.forEach(q => {
      q.required = true;
    });
  });
  await db.collection('formconfigs').updateOne({_id: 'mentor_setup'}, {$set: {schema: config.schema}});
  console.log('Done');
  process.exit(0);
});
