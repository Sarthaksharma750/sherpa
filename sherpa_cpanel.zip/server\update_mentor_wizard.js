const mongoose = require('mongoose');
require('dotenv').config();
const FormConfig = require('./models/FormConfig');

async function run() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to DB');

    const config = await FormConfig.findById('mentor_setup');
    if (config) {
      if (config.schema.pages.length > 2) {
        config.schema.pages = config.schema.pages.slice(0, 2);
        config.markModified('schema.pages');
        await config.save();
        console.log('Successfully truncated mentor_setup config to 2 pages');
      } else {
        console.log('mentor_setup config already has 2 or fewer pages');
      }
    } else {
      console.log('mentor_setup config not found');
    }
  } catch (error) {
    console.error('Migration failed', error);
  } finally {
    mongoose.connection.close();
  }
}

run();
