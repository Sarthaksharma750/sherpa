const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const userSchema = new mongoose.Schema({
  _id: String,
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String, default: null },
  password: { type: String, required: true },
  role: { type: String, default: 'aspirant' },
  bio: String,
  profileImage: String,
  designation: String,
  specialization: String,
  hourlyRate: Number,
  firstSessionFree: { type: Boolean, default: false },
  isApproved: { type: Boolean, default: false },
  isVerified: { type: Boolean, default: false },
  skills: [String],
  walletBalance: { type: Number, default: 0 },
  upiId: { type: String, default: null },
  upiName: { type: String, default: null },
  hasPendingWithdrawal: { type: Boolean, default: false },
  experiences: [{
    title: String,
    company: String,
    year: String
  }],
  preparingFor: String,
  clearedYear: String,
  subjects: [String],
  prelimsScore: String,
  mainsScore: String,
  interviewScore: String,
  interests: [String],
  languages: [String],
  onboardingData: { type: mongoose.Schema.Types.Mixed, default: {} },
  setupCompleted: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
userSchema.plugin(transformPlugin);
module.exports = mongoose.model('User', userSchema);