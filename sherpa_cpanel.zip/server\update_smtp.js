require('dotenv').config();
const mongoose = require('mongoose');

async function updateDb() {
  await mongoose.connect(process.env.MONGO_URI);
  const result = await mongoose.connection.db.collection('settings').updateOne(
    { _id: 'site_settings' },
    { $set: { 
        smtpServer: 'sherpa.acrobite.in',
        smtpPort: '465',
        smtpUser: 'no-reply@sherpa.acrobite.in',
        smtpPass: 'sherpa@123'
    }},
    { upsert: true }
  );
  console.log('Update SMTP result:', result);
  process.exit(0);
}

updateDb();
