const fs = require('fs');
const path = require('path');

const modelsDir = path.join(__dirname, 'models');

const models = {
  'User.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const userSchema = new mongoose.Schema({
  _id: String,
  fullName: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  role: { type: String, default: 'aspirant' },
  bio: String,
  profileImage: String,
  designation: String,
  specialization: String,
  hourlyRate: Number,
  isApproved: { type: Boolean, default: false },
  skills: [String],
  walletBalance: { type: Number, default: 0 },
  experiences: [{
    title: String,
    company: String,
    year: String
  }],
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
userSchema.plugin(transformPlugin);
module.exports = mongoose.model('User', userSchema);`,

  'Booking.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const bookingSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  aspirantId: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  duration: { type: String, default: "30" },
  status: { type: String, default: 'pending' },
  paymentStatus: { type: String, default: 'pending' },
  meetLink: String,
  totalAmount: Number,
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
bookingSchema.plugin(transformPlugin);
module.exports = mongoose.model('Booking', bookingSchema);`,

  'MentorSchedule.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const dayScheduleSchema = new mongoose.Schema({
  day: String,
  active: Boolean,
  start: String,
  end: String
}, { _id: false });

const mentorScheduleSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  week: [dayScheduleSchema],
  month: { type: Map, of: new mongoose.Schema({ start: String, end: String }, { _id: false }) }
}, { _id: false });
mentorScheduleSchema.plugin(transformPlugin);
module.exports = mongoose.model('MentorSchedule', mentorScheduleSchema, 'mentors_schedule');`,

  'Review.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const reviewSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  aspirantId: { type: String, required: true },
  bookingId: { type: String, required: true },
  rating: { type: Number, required: true },
  comment: String,
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
reviewSchema.plugin(transformPlugin);
module.exports = mongoose.model('Review', reviewSchema);`,

  'Notification.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const notificationSchema = new mongoose.Schema({
  _id: String,
  userId: { type: String, required: true },
  title: { type: String, required: true },
  message: { type: String, required: true },
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
notificationSchema.plugin(transformPlugin);
module.exports = mongoose.model('Notification', notificationSchema);`,

  'Conversation.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const conversationSchema = new mongoose.Schema({
  _id: String,
  participants: [String],
  lastMessage: String,
  updatedAt: { type: Date, default: Date.now }
}, { _id: false });
conversationSchema.plugin(transformPlugin);
module.exports = mongoose.model('Conversation', conversationSchema);`,

  'Message.js': `const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const messageSchema = new mongoose.Schema({
  _id: String,
  conversationId: { type: String, required: true },
  senderId: { type: String, required: true },
  text: { type: String, required: true },
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
messageSchema.plugin(transformPlugin);
module.exports = mongoose.model('Message', messageSchema);`
};

for (const [filename, content] of Object.entries(models)) {
  fs.writeFileSync(path.join(modelsDir, filename), content);
}
console.log('Models re-created with string duration!');
