require('dotenv').config();
const mongoose = require('mongoose');

const FormConfigSchema = new mongoose.Schema({
  _id: String,
  schema: Object
}, { strict: false });

const FormConfig = mongoose.model('FormConfig', FormConfigSchema, 'formconfigs');

async function checkSchema() {
  try {
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    
    const doc = await FormConfig.findOne({ _id: 'mentor_setup' });
    if (doc) {
      const qualPage = doc.schema.pages.find(p => p.id === 'page_qualification');
      console.log(JSON.stringify(qualPage.questions, null, 2));
    }
  } catch (err) {
    console.error(err);
  } finally {
    mongoose.disconnect();
  }
}

checkSchema();
