const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const conversationSchema = new mongoose.Schema({
  _id: String,
  participants: [String],
  lastMessage: String,
  updatedAt: { type: Date, default: Date.now }
}, { _id: false });
conversationSchema.plugin(transformPlugin);
module.exports = mongoose.model('Conversation', conversationSchema);