const express = require('express');
const path = require('path');
const cors = require('cors');
const mongoose = require('mongoose');
require('dotenv').config({ path: require('path').join(__dirname, '.env') });
const { OAuth2Client } = require('google-auth-library');
const nodemailer = require('nodemailer');
const emailService = require('./services/emailService');
const multer = require('multer');
const fs = require('fs');

const app = express();
app.use(cors());
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ limit: '10mb', extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));
app.use('/marksheet', express.static(path.join(__dirname, 'marksheet')));

// Community is currently disabled, so we don't load sequelize/sqlite3 routes
// const communityRoutes = require('./routes/community');
// app.use('/api/community', communityRoutes);

// Configure Multer for File Uploads
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    let dir = path.join(__dirname, 'uploads');
    if (req.body.isMarksheet === 'true') {
      dir = path.join(__dirname, 'marksheet');
    }
    if (!fs.existsSync(dir)){
        fs.mkdirSync(dir, { recursive: true });
    }
    cb(null, dir);
  },
  filename: function (req, file, cb) {
    if (req.body.isMarksheet === 'true' && req.body.email && req.body.examName) {
      const emailPrefix = req.body.email.split('@')[0];
      const examName = req.body.examName.toLowerCase();
      cb(null, `${emailPrefix}_${examName}${path.extname(file.originalname)}`);
    } else {
      const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
      cb(null, uniqueSuffix + path.extname(file.originalname));
    }
  }
});
const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

app.post('/api/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }
  let fileUrl = `/uploads/${req.file.filename}`;
  if (req.body.isMarksheet === 'true') {
    fileUrl = `/marksheet/${req.file.filename}`;
  }
  res.json({ url: fileUrl });
});

app.use((req, res, next) => {
  console.log(`[DEBUG] Received ${req.method} request to ${req.url}`);
  next();
});

// Import Models
const User = require('./models/User');
const Booking = require('./models/Booking');
const Conversation = require('./models/Conversation');
const Message = require('./models/Message');
const Notification = require('./models/Notification');
const Review = require('./models/Review');
const MentorSchedule = require('./models/MentorSchedule');
const Payout = require('./models/Payout');
const Report = require('./models/Report');
const Setting = require('./models/Setting');
const Exam = require('./models/Exam');
const Otp = require('./models/Otp');
const FormConfig = require('./models/FormConfig');
const Short = require('./models/Short');
const LandingButton = require('./models/LandingButton');

const models = {
  users: User,
  bookings: Booking,
  conversations: Conversation,
  messages: Message,
  notifications: Notification,
  reviews: Review,
  mentors_schedule: MentorSchedule,
  payouts: Payout,
  reports: Report,
  settings: Setting,
  exams: Exam,
  otps: Otp,
  form_configs: FormConfig,
  landing_buttons: LandingButton,
  site_analytics: require('./models/SiteAnalytics'),
  shorts: Short
};

// Connect to MongoDB
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true
}).then(() => {
  console.log('Connected to MongoDB Atlas');

  // Seed Form Configs if missing
  const seedFormConfigs = async () => {
    try {
      const existing = await FormConfig.findOne({ _id: 'mentor_setup' });
      if (!existing) {
        await FormConfig.create({
          _id: 'mentor_setup',
          schema: {
            pages: [
              {
                id: 'page_1',
                title: 'Your UPSC experience',
                description: 'Tell us about your UPSC Civil Services Examination attempts and the stages you cleared.',
                questions: [
                  { id: 'upscExperience', type: 'custom_upsc_experience', label: '' }
                ]
              },
              {
                id: 'page_2',
                title: 'About You',
                description: 'Help students get to know you, your background and your mentoring experience.',
                questions: [
                  { id: 'aboutYouCustom', type: 'custom_about_you', label: '' }
                ]
              },
              {
                id: 'page_3',
                title: 'Mentor Dashboard',
                questions: [
                  { id: 'dashboardHub', type: 'custom_dashboard', label: '' }
                ]
              }
            ]
          }
        });
        console.log('Seeded mentor_setup FormConfig');
      }
      await FormConfig.findOneAndUpdate(
        { _id: 'aspirant_setup' },
        {
          schema: {
            pages: [
              {
                id: 'page_1',
                title: 'Your Stage',
                description: 'What stage of preparation are you currently in?',
                questions: [
                  { id: 'aspirantStage', type: 'custom_aspirant_stage', label: '', required: true }
                ]
              },
              {
                id: 'page_2',
                title: 'About You',
                description: 'Help mentors get to know you, your background and your goals.',
                questions: [
                  { id: 'aspirantAboutYou', type: 'custom_aspirant_about_you', label: '', required: true }
                ]
              },
              {
                id: 'page_3',
                title: 'How we can help',
                description: 'Select the areas where you need guidance.',
                questions: [
                  { id: 'aspirantHelp', type: 'custom_aspirant_help', label: '', required: true }
                ]
              },
              {
                id: 'page_4',
                title: 'Profile Preview',
                questions: [
                  { id: 'aspirantPreview', type: 'custom_aspirant_preview', label: '', required: true }
                ]
              }
            ]
          }
        },
        { upsert: true }
      );
      console.log('Seeded (Updated) aspirant_setup FormConfig');
    } catch (err) {
      console.error('Failed to seed form configs:', err);
    }
  };
  seedFormConfigs();

  // Cleanup old booking screenshots to save space
  const cleanupBookingScreenshots = async () => {
    try {
      const bookings = await Booking.find({ paymentScreenshot: { $exists: true, $ne: null } });
      const now = new Date();
      let count = 0;
      
      for (const booking of bookings) {
        let isExpired = false;
        
        if (booking.endedAt) {
          const diffHours = (now.getTime() - new Date(booking.endedAt).getTime()) / (1000 * 60 * 60);
          if (diffHours > 24) isExpired = true;
        } else if (booking.date && booking.time) {
          try {
             // Create date from "YYYY-MM-DD" and "HH:MM"
             const bookingDateTime = new Date(`${booking.date}T${booking.time}`);
             const diffHours = (now.getTime() - bookingDateTime.getTime()) / (1000 * 60 * 60);
             if (diffHours > 24) isExpired = true;
          } catch (e) {
             console.error("Error parsing booking date/time for cleanup");
          }
        } else if (booking.createdAt) {
          const diffHours = (now.getTime() - new Date(booking.createdAt).getTime()) / (1000 * 60 * 60);
          if (diffHours > 72) isExpired = true; // Fallback for old pending bookings
        }

        if (isExpired) {
          await Booking.updateOne({ _id: booking._id }, { $unset: { paymentScreenshot: "" } });
          count++;
        }
      }
      
      if (count > 0) {
        console.log(`Cleaned up ${count} old booking screenshots to save space`);
      }
    } catch (err) {
      console.error('Failed to cleanup booking screenshots:', err);
    }
  };
  
  // Run on startup, then every hour
  cleanupBookingScreenshots();
  setInterval(cleanupBookingScreenshots, 60 * 60 * 1000);

}).catch(err => console.error('MongoDB connection error:', err));

// Helper function to convert json-server queries to Mongoose queries
const buildQuery = (reqQuery) => {
  const query = { ...reqQuery };
  let sort = {};
  
  if (query._sort) {
    const order = query._order === 'desc' ? -1 : 1;
    sort[query._sort] = order;
    delete query._sort;
    delete query._order;
  }
  
  // Convert string booleans to actual booleans to prevent Mongoose CastErrors
  for (let key in query) {
    if (query[key] === 'true') query[key] = true;
    if (query[key] === 'false') query[key] = false;
  }
  
  // Special case: full text search or simple string match, but exact match is fine for our current use cases
  
  return { filter: query, sort };
};

// Custom Admin Stats Endpoint
app.get('/api/admin/stats', async (req, res) => {
  try {
    const usersCount = await models.users.countDocuments();
    const aspirantsCount = await models.users.countDocuments({ role: 'aspirant' });
    const mentorsCount = await models.users.countDocuments({ role: 'mentor' });
    
    const bookings = await models.bookings.find();
    const totalRequests = bookings.length;
    const acceptedBookings = bookings.filter(b => b.status === 'accepted').length;
    const successfulBookings = bookings.filter(b => b.status === 'successful');
    const missedBookings = bookings.filter(b => b.status === 'missed').length;
    
    const totalEarnings = successfulBookings.reduce((sum, b) => sum + (b.price || 0), 0) * 0.15;
    
    const examsCount = await models.exams.countDocuments();
    const allExams = await models.exams.find();
    const subjectsCount = allExams.reduce((sum, ex) => sum + (ex.subjects ? ex.subjects.length : 0), 0);

    const analytics = await models.site_analytics.findOne({ _id: 'global_stats' }) || { totalViews: 0, uniqueViews: 0 };

    res.json({
      totalUsers: usersCount,
      totalAspirants: aspirantsCount,
      totalMentors: mentorsCount,
      totalViews: analytics.totalViews,
      uniqueViews: analytics.uniqueViews,
      totalRequests,
      acceptedBookings,
      successfulBookings: successfulBookings.length,
      missedBookings,
      totalExams: examsCount,
      totalSubjects: subjectsCount,
      totalEarnings
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Admin Users Stats Endpoint
app.get('/api/admin/users-stats', async (req, res) => {
  try {
    const users = await models.users.find();
    const bookings = await models.bookings.find();

    const usersWithStats = users.map(user => {
      let successfulSessions = 0;
      let totalEarnings = 0;

      if (user.role === 'mentor') {
        const mentorBookings = bookings.filter(b => b.mentorId === user._id || b.mentorId === user.id);
        const successful = mentorBookings.filter(b => b.status === 'successful');
        successfulSessions = successful.length;
        // Mentors keep 85% of total booking price
        totalEarnings = successful.reduce((sum, b) => sum + (b.price || 0), 0) * 0.85;
      } else if (user.role === 'aspirant') {
        const aspirantBookings = bookings.filter(b => b.aspirantId === user._id || b.aspirantId === user.id);
        const successful = aspirantBookings.filter(b => b.status === 'successful');
        successfulSessions = successful.length;
      }

      // Convert Mongoose doc to lean object if needed
      const uObj = user.toJSON ? user.toJSON() : user;
      return {
        ...uObj,
        successfulSessions,
        totalEarnings
      };
    });

    res.json(usersWithStats);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Analytics Tracking
app.post('/api/analytics/view', async (req, res) => {
  try {
    const { token } = req.body;
    let analytics = await models.site_analytics.findOne({ _id: 'global_stats' });
    if (!analytics) {
      analytics = new models.site_analytics({ _id: 'global_stats', totalViews: 0, uniqueViews: 0, uniqueVisitors: [] });
    }
    
    analytics.totalViews += 1;
    if (token && !analytics.uniqueVisitors.includes(token)) {
      analytics.uniqueVisitors.push(token);
      analytics.uniqueViews += 1;
    }
    await analytics.save();
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Generic REST endpoints to mimic json-server
app.get('/api/:resource', async (req, res) => {
  const Model = models[req.params.resource];
  if (!Model) return res.status(404).send('Resource not found');
  
  try {
    const { filter, sort } = buildQuery(req.query);
    const data = await Model.find(filter).sort(sort);
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.get('/api/:resource/:id', async (req, res) => {
  const Model = models[req.params.resource];
  if (!Model) return res.status(404).send('Resource not found');
  
  try {
    const data = await Model.findById(req.params.id);
    if (!data) return res.status(404).json({});
    res.json(data);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/auth/google', async (req, res) => {
  try {
    const { token, role } = req.body;
    
    const Setting = models['settings'];
    const settings = await Setting.findOne({ _id: 'site_settings' });
    if (!settings || !settings.googleClientId) {
      return res.status(500).json({ error: 'Google Login is not configured on the server.' });
    }

    const client = new OAuth2Client(settings.googleClientId);
    
    let payload;
    try {
      // Try verifying as ID token first (if they use standard GoogleLogin)
      const ticket = await client.verifyIdToken({
        idToken: token,
        audience: settings.googleClientId,
      });
      payload = ticket.getPayload();
    } catch (e) {
      // If it fails, assume it's an access token from useGoogleLogin
      const response = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
        headers: { Authorization: `Bearer ${token}` }
      });
      payload = await response.json();
    }
    
    if (!payload || !payload.email) return res.status(400).json({ error: 'Invalid Google token.' });
    
    const { email, name, picture } = payload;
    
    const User = models['users'];
    let user = await User.findOne({ email });
    
    if (!user) {
      if (!role) {
        // We only allow registration if a role was explicitly passed (e.g. from Registration page)
        // Actually, if we want seamless login we can ask for role on register, but on login just fail if not found.
        return res.status(404).json({ error: 'User not found. Please register first.' });
      }
      
      const newUserId = Date.now().toString() + Math.random().toString(36).substring(2, 7);
      user = new User({
        _id: newUserId,
        email,
        name,
        profileImage: picture,
        role,
        authProvider: 'google',
        setupCompleted: false,
        created_at: new Date().toISOString(),
      });
      await user.save();
    }
    
    res.json(user);
    
  } catch (err) {
    console.error('Google auth error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Send OTP Route
app.post('/api/auth/send-otp', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email) return res.status(400).json({ error: 'Email is required.' });

    const Setting = models['settings'];
    const settings = await Setting.findOne({ _id: 'site_settings' });
    if (!settings || !settings.smtpServer || !settings.smtpUser || !settings.smtpPass) {
      return res.status(500).json({ error: 'SMTP settings are not configured on the server.' });
    }

    // Generate 6 digit OTP
    const otp = Math.floor(100000 + Math.random() * 900000).toString();

    // Upsert into Otp collection
    await Otp.findOneAndUpdate(
      { email },
      { otp, createdAt: new Date() },
      { upsert: true, new: true }
    );

    // Setup Nodemailer
    const transporter = nodemailer.createTransport({
      host: settings.smtpServer,
      port: parseInt(settings.smtpPort, 10) || 465,
      secure: true,
      auth: {
        user: settings.smtpUser,
        pass: settings.smtpPass,
      },
    });

    const mailOptions = {
      from: `"${settings.websiteName || 'Sherpa'}" <${settings.smtpUser}>`,
      to: email,
      subject: 'Your Registration OTP',
      html: `
        <div style="font-family: Arial, sans-serif; padding: 20px; color: #333;">
          <h2 style="color: #215A9C;">Welcome to ${settings.websiteName || 'Sherpa'}!</h2>
          <p>Please use the following One-Time Password (OTP) to complete your registration. This OTP is valid for 10 minutes.</p>
          <h1 style="font-size: 36px; letter-spacing: 5px; color: #ea580c; background: #f9f9f9; padding: 10px 20px; border-radius: 8px; display: inline-block;">${otp}</h1>
          <p>If you did not request this, please ignore this email.</p>
        </div>
      `,
    };

    transporter.sendMail(mailOptions).catch(err => {
      console.error('Async Send OTP email error:', err);
    });

    res.json({ message: 'OTP sent successfully.' });

  } catch (err) {
    console.error('Send OTP error:', err);
    res.status(500).json({ error: err.message || 'Failed to prepare OTP.' });
  }
});

// Verify OTP Route
app.post('/api/auth/verify-otp', async (req, res) => {
  try {
    const { email, otp } = req.body;
    if (!email || !otp) return res.status(400).json({ error: 'Email and OTP are required.' });

    const record = await Otp.findOne({ email });
    if (!record) {
      return res.status(400).json({ error: 'No OTP found or it has expired. Please request a new one.' });
    }

    if (record.otp !== otp) {
      return res.status(400).json({ error: 'Invalid OTP.' });
    }

    // OTP matched, remove it
    await Otp.deleteOne({ email });
    res.json({ message: 'OTP verified successfully.' });

  } catch (err) {
    console.error('Verify OTP error:', err);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.post('/api/notifications/broadcast', async (req, res) => {
  try {
    const { title, message } = req.body;
    if (!title || !message) {
      return res.status(400).json({ error: 'Title and message are required' });
    }
    const User = models['users'];
    const Notification = models['notifications'];
    if (!User || !Notification) {
       return res.status(500).json({ error: 'Required models not found' });
    }

    const users = await User.find({});
    const notifications = users.map(user => ({
      _id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
      userId: user._id || user.id,
      title,
      message,
      type: 'system',
      read: false
    }));

    if (notifications.length > 0) {
      await Notification.insertMany(notifications);
    }
    
    res.status(200).json({ message: `Successfully sent notification to ${users.length} users` });
  } catch (err) {
    console.error('Error broadcasting notification:', err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/:resource', async (req, res) => {
  const Model = models[req.params.resource];
  if (!Model) return res.status(404).send('Resource not found');
  
  try {
    if (!req.body._id && !req.body.id) {
      req.body._id = Date.now().toString() + Math.random().toString(36).substring(2, 7);
    } else if (req.body.id && !req.body._id) {
      req.body._id = req.body.id;
    }
    const newItem = new Model(req.body);
    const savedItem = await newItem.save();
    
    // Automated message & email for booking request
    if (req.params.resource === 'bookings') {
      try {
        const User = models['users'];
        const mentor = await User.findOne({ _id: savedItem.mentorId });
        const aspirant = await User.findOne({ _id: savedItem.aspirantId });
        if (mentor && aspirant) {
           const origin = req.headers.origin || (req.headers.referer ? req.headers.referer.split('/').slice(0, 3).join('/') : `http://localhost:5173`);
           emailService.sendSessionRequestEmail(mentor.email, mentor.fullName, aspirant.fullName, savedItem.date, savedItem.time, savedItem.duration, origin);
        }

        const Conversation = models['conversations'];
        const Message = models['messages'];
        if (Conversation && Message) {
          let conv = await Conversation.findOne({
            participants: { $all: [savedItem.mentorId, savedItem.aspirantId] }
          });
          if (!conv) {
            conv = new Conversation({
              _id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
              participants: [savedItem.mentorId, savedItem.aspirantId]
            });
            await conv.save();
          }
          const msgText = `📅 Session Requested: ${savedItem.date} at ${savedItem.time} for ${savedItem.duration} mins.`;
          const msg = new Message({
            _id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
            conversationId: conv._id,
            senderId: savedItem.aspirantId,
            text: msgText
          });
          await msg.save();
          conv.lastMessage = msgText;
          conv.updatedAt = Date.now();
          await conv.save();
        }
      } catch (err) {
        console.error('Failed to create automated chat message for booking request', err);
      }
    }

    if (req.params.resource === 'messages') {
       try {
         const Conversation = models['conversations'];
         const User = models['users'];
         const conv = await Conversation.findOne({ _id: savedItem.conversationId });
         if (conv) {
           const receiverId = conv.participants.find(p => p !== savedItem.senderId);
           if (receiverId) {
             const receiver = await User.findOne({ _id: receiverId });
             const sender = await User.findOne({ _id: savedItem.senderId });
             if (receiver && sender) {
                const origin = req.headers.origin || (req.headers.referer ? req.headers.referer.split('/').slice(0, 3).join('/') : `http://localhost:5173`);
                emailService.sendChatMessageEmail(receiver.email, receiver.fullName, sender.fullName, savedItem.text, savedItem.senderId, origin);
             }
           }
         }
       } catch (err) {
         console.error('Failed to send chat message email', err);
       }
    }

    res.status(201).json(savedItem);
  } catch (err) {
    console.error(`Error saving ${req.params.resource}:`, err);
    res.status(500).json({ error: err.message, stack: err.stack });
  }
});

app.patch('/api/:resource/:id', async (req, res) => {
  const Model = models[req.params.resource];
  if (!Model) return res.status(404).send('Resource not found');
  
  try {
    let updateQuery = { ...req.body };
    if (updateQuery.addDurationSeconds !== undefined) {
      const { addDurationSeconds, ...rest } = updateQuery;
      updateQuery = { ...rest, $inc: { actualDurationSeconds: addDurationSeconds } };
    }
    
    // Mongoose interprets the object directly in findByIdAndUpdate. 
    // If we use $inc, we need to ensure the rest is in $set.
    let finalUpdate = updateQuery;
    if (updateQuery.$inc) {
      const { $inc, ...$set } = updateQuery;
      finalUpdate = { $inc, $set };
    }

    const updatedItem = await Model.findByIdAndUpdate(req.params.id, finalUpdate, { new: true });

    // Automated message & email for booking accepted
    if (req.params.resource === 'bookings' && req.body.status === 'accepted') {
      try {
        const User = models['users'];
        const mentor = await User.findOne({ _id: updatedItem.mentorId });
        const aspirant = await User.findOne({ _id: updatedItem.aspirantId });
        if (mentor && aspirant) {
           const origin = req.headers.origin || (req.headers.referer ? req.headers.referer.split('/').slice(0, 3).join('/') : `http://localhost:5173`);
           emailService.sendSessionAcceptedEmail(aspirant.email, aspirant.fullName, mentor.fullName, updatedItem.date, updatedItem.time, origin);
        }

        const Conversation = models['conversations'];
        const Message = models['messages'];
        if (Conversation && Message) {
          let conv = await Conversation.findOne({
            participants: { $all: [updatedItem.mentorId, updatedItem.aspirantId] }
          });
          if (!conv) {
            conv = new Conversation({
              _id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
              participants: [updatedItem.mentorId, updatedItem.aspirantId]
            });
            await conv.save();
          }
          const msgText = `✅ Session Accepted! Looking forward to meeting you on ${updatedItem.date} at ${updatedItem.time}.`;
          const msg = new Message({
            _id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
            conversationId: conv._id,
            senderId: updatedItem.mentorId,
            text: msgText
          });
          await msg.save();
          conv.lastMessage = msgText;
          conv.updatedAt = Date.now();
          await conv.save();
        }
      } catch (err) {
        console.error('Failed to create automated chat message for booking acceptance', err);
      }
    }

    res.json(updatedItem);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.delete('/api/:resource/:id', async (req, res) => {
  const Model = models[req.params.resource];
  if (!Model) return res.status(404).send('Resource not found');
  
  try {
    await Model.findByIdAndDelete(req.params.id);
    res.json({});
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const Razorpay = require('razorpay');
const crypto = require('crypto');

app.post('/api/razorpay/create-order', async (req, res) => {
  try {
    const razorpay = new Razorpay({
      key_id: process.env.RAZORPAY_KEY,
      key_secret: process.env.RAZORPAY_SECRET,
    });
    const options = {
      amount: req.body.amount * 100, // amount in paise
      currency: 'INR',
      receipt: 'receipt_order_' + Date.now()
    };
    const order = await razorpay.orders.create(options);
    res.json(order);
  } catch (err) {
    console.error("Razorpay create-order error:", err);
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/razorpay/verify-payment', (req, res) => {
  try {
    const { razorpay_order_id, razorpay_payment_id, razorpay_signature } = req.body;
    const secret = process.env.RAZORPAY_SECRET;
    
    const shasum = crypto.createHmac('sha256', secret);
    shasum.update(`${razorpay_order_id}|${razorpay_payment_id}`);
    const digest = shasum.digest('hex');

    if (digest === razorpay_signature) {
      res.json({ success: true });
    } else {
      res.status(400).json({ success: false, error: 'Transaction signature mismatch!' });
    }
  } catch (err) {
    console.error("Razorpay verify-payment error:", err);
    res.status(500).json({ error: err.message });
  }
});

// Serve static React frontend for Shared Hosting (check ../dist or current directory root)
const distPath = fs.existsSync(path.join(__dirname, '../dist/index.html'))
  ? path.join(__dirname, '../dist')
  : path.join(__dirname, '..');

app.use(express.static(distPath));

app.use((req, res) => {
  res.sendFile(path.join(distPath, 'index.html'));
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log('Express API running on port ' + PORT);
});
