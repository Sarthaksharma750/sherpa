const mongoose = require('mongoose');

const examSchema = new mongoose.Schema({
  _id: String,
  name: { type: String, required: true, unique: true },
  subjects: [{ type: String }],
}, { _id: false, timestamps: true });

const transformPlugin = require('./plugins/transform');
examSchema.plugin(transformPlugin);

module.exports = mongoose.model('Exam', examSchema);
