const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const notificationSchema = new mongoose.Schema({
  _id: String,
  userId: { type: String, required: true },
  title: { type: String, required: true },
  message: { type: String, required: true },
  read: { type: Boolean, default: false },
  createdAt: { type: Date, default: Date.now, expires: '4d' }
}, { _id: false });
notificationSchema.plugin(transformPlugin);
module.exports = mongoose.model('Notification', notificationSchema);