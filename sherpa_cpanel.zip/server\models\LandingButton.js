const mongoose = require('mongoose');

const landingButtonSchema = new mongoose.Schema({
  text: {
    type: String,
    required: true
  },
  url: {
    type: String,
    required: true
  },
  orderIndex: {
    type: Number,
    required: true,
    default: 0
  },
  variant: {
    type: String,
    enum: ['primary', 'secondary'],
    default: 'primary'
  }
}, { timestamps: true });

module.exports = mongoose.model('LandingButton', landingButtonSchema);
