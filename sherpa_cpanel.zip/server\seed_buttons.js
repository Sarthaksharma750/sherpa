require('dotenv').config();
const mongoose = require('mongoose');
const LandingButton = require('./models/LandingButton');

async function seed() {
  await mongoose.connect(process.env.MONGO_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
  });
  
  const count = await LandingButton.countDocuments();
  if (count === 0) {
    await LandingButton.create([
      { text: 'Find Mentor', url: '/explore', orderIndex: 1, variant: 'primary' },
      { text: 'Become Mentor', url: '/register?role=mentor', orderIndex: 2, variant: 'secondary' }
    ]);
    console.log('Default landing buttons seeded.');
  } else {
    console.log('Buttons already exist. Skipping seed.');
  }
  process.exit();
}
seed();
