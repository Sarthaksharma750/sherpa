const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const bookingSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  aspirantId: { type: String, required: true },
  date: { type: String, required: true },
  time: { type: String, required: true },
  duration: { type: String, default: "30" },
  status: { type: String, default: 'pending' },
  paymentStatus: { type: String, default: 'pending' },
  paymentScreenshot: { type: String, default: null },
  paymentId: { type: String, default: null },
  meetLink: String,
  mentorPeerId: String,
  aspirantPeerId: String,
  startedAt: Date,
  endedAt: Date,
  actualDurationSeconds: { type: Number, default: 0 },
  price: Number,
  totalAmount: Number,
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
bookingSchema.plugin(transformPlugin);
module.exports = mongoose.model('Booking', bookingSchema);