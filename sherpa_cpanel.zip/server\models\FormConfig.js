const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const formConfigSchema = new mongoose.Schema({
  _id: String, // e.g. 'mentor_setup'
  schema: { type: mongoose.Schema.Types.Mixed, default: { pages: [] } },
}, { _id: false, timestamps: true });

formConfigSchema.plugin(transformPlugin);

module.exports = mongoose.model('FormConfig', formConfigSchema);
