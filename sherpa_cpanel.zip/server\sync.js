const mongoose = require('mongoose');
require('dotenv').config();

const User = require('./models/User');
const Booking = require('./models/Booking');

async function syncWallets() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to DB');

    const mentors = await User.find({ role: 'mentor' });
    
    for (const mentor of mentors) {
      const bookings = await Booking.find({ mentorId: mentor._id, status: 'successful' });
      const totalRevenue = bookings.reduce((sum, b) => sum + (b.price || 0), 0);
      const earnings = totalRevenue * 0.85;

      if (mentor.walletBalance === 0 && earnings > 0) {
        mentor.walletBalance = earnings;
        await mentor.save();
        console.log(`Updated wallet for ${mentor.fullName}: ₹${earnings}`);
      }
    }
    
    console.log('Wallet sync complete!');
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

syncWallets();
