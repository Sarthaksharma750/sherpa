require('dotenv').config();
const mongoose = require('mongoose');

async function updateDb() {
  await mongoose.connect(process.env.MONGO_URI);
  const result = await mongoose.connection.db.collection('settings').updateOne(
    { _id: 'site_settings' },
    { $set: { 
        googleClientId: '418363139173-1frcv5ulnht2fqllj32dkgugb7mhqhjp.apps.googleusercontent.com',
        googleClientSecret: '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'
    }},
    { upsert: true }
  );
  console.log('Update result:', result);
  process.exit(0);
}

updateDb();
