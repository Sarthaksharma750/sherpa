const mongoose = require('mongoose');

const settingSchema = new mongoose.Schema({
  _id: String,
  websiteName: { type: String, default: 'Sherpa' },
  websiteLogo: { type: String, default: '' },
  websiteLogoDark: { type: String, default: '' },
  email: { type: String, default: '' },
  phone: { type: String, default: '' },
  smtpServer: { type: String, default: '' },
  smtpPort: { type: String, default: '' },
  smtpUser: { type: String, default: '' },
  smtpPass: { type: String, default: '' },
  googleClientId: { type: String, default: '' },
  googleClientSecret: { type: String, default: '' },
  communityEnabled: { type: Boolean, default: false },
}, { _id: false, timestamps: true });

const transformPlugin = require('./plugins/transform');
settingSchema.plugin(transformPlugin);

module.exports = mongoose.model('Setting', settingSchema);
