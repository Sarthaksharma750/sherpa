const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const reviewSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  aspirantId: { type: String, required: true },
  bookingId: { type: String, required: true },
  rating: { type: Number, required: true },
  comment: String,
  createdAt: { type: Date, default: Date.now }
}, { _id: false });
reviewSchema.plugin(transformPlugin);
module.exports = mongoose.model('Review', reviewSchema);