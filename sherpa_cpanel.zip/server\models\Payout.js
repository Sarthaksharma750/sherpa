const mongoose = require('mongoose');
const transformPlugin = require('./plugins/transform');

const payoutSchema = new mongoose.Schema({
  _id: String,
  mentorId: { type: String, required: true },
  amount: { type: Number, required: true },
  adminUpiId: { type: String, required: true },
  date: { type: Date, default: Date.now }
}, { _id: false });

payoutSchema.plugin(transformPlugin);

module.exports = mongoose.model('Payout', payoutSchema);
