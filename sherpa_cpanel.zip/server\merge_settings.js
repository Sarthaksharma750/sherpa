require('dotenv').config();
const m = require('mongoose');
m.connect(process.env.MONGO_URI).then(async () => {
  const db = m.connection.db;
  const oldSettings = await db.collection('settings').findOne({ _id: '1790541679618l3z2m' });
  if (oldSettings) {
    await db.collection('settings').updateOne(
      { _id: 'site_settings' },
      { $set: { 
          websiteName: oldSettings.websiteName,
          websiteLogo: oldSettings.websiteLogo,
          websiteLogoDark: oldSettings.websiteLogoDark,
          email: oldSettings.email,
          phone: oldSettings.phone
      }}
    );
    await db.collection('settings').deleteOne({ _id: '1790541679618l3z2m' });
    console.log('Migrated old settings and deleted old document.');
  } else {
    console.log('No old document found.');
  }
  process.exit(0);
});
