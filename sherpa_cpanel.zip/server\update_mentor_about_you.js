const mongoose = require('mongoose');
require('dotenv').config();
const FormConfig = require('./models/FormConfig');

async function run() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to DB');

    const config = await FormConfig.findById('mentor_setup');
    if (config) {
      const page2Index = config.schema.pages.findIndex((p) => p.id === 'page_2');
      if (page2Index !== -1) {
        config.schema.pages[page2Index] = {
          id: 'page_2',
          title: 'About You',
          description: 'Help students get to know you, your background and your mentoring experience.',
          questions: [
            { id: 'aboutYouCustom', type: 'custom_about_you', label: '' }
          ]
        };
        config.markModified('schema.pages');
        await config.save();
        console.log('Successfully updated mentor_setup config page_2');
      } else {
        console.log('page_2 not found');
      }
    } else {
      console.log('mentor_setup config not found');
    }
  } catch (error) {
    console.error('Migration failed', error);
  } finally {
    mongoose.connection.close();
  }
}

run();
