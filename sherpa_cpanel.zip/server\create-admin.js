const mongoose = require('mongoose');
require('dotenv').config();

const User = require('./models/User');

async function createAdmin() {
  try {
    await mongoose.connect(process.env.MONGO_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true
    });
    console.log('Connected to DB');

    const adminEmail = 'sarthak@sherpa.com';
    let admin = await User.findOne({ email: adminEmail });

    if (!admin) {
      admin = new User({
        _id: Date.now().toString() + Math.random().toString(36).substring(2, 7),
        fullName: 'Sarthak Admin',
        email: adminEmail,
        password: 'sherpa@123',
        role: 'admin',
        setupCompleted: true
      });
      await admin.save();
      console.log('Created admin user successfully.');
    } else {
      admin.role = 'admin';
      admin.password = 'sherpa@123';
      admin.setupCompleted = true;
      await admin.save();
      console.log('Updated existing user to admin.');
    }
    
    process.exit(0);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

createAdmin();
