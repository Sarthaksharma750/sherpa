const mongoose = require('mongoose');

const shortSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
  },
  username: {
    type: String,
    required: true,
  },
  duration: {
    type: String,
    required: true,
  },
  youtubeUrl: {
    type: String,
    required: true,
  },
  color: {
    type: String,
    enum: ['slate', 'blue', 'grey', 'purple'],
    default: 'slate'
  }
}, { timestamps: true });

const Short = mongoose.model('Short', shortSchema);
module.exports = Short;
