const mongoose = require('mongoose');
const fs = require('fs');
const path = require('path');
require('dotenv').config();

const User = require('./models/User');
const Booking = require('./models/Booking');
const Conversation = require('./models/Conversation');
const Message = require('./models/Message');
const Notification = require('./models/Notification');
const Review = require('./models/Review');
const MentorSchedule = require('./models/MentorSchedule');

const MIGRATION_MAP = [
  { file: '../database/users/users.json', key: 'users', model: User },
  { file: '../database/users/users.json', key: 'bookings', model: Booking },
  { file: '../database/users/users.json', key: 'notifications', model: Notification },
  { file: '../database/users/users.json', key: 'reviews', model: Review },
  { file: '../database/users/users.json', key: 'mentors_schedule', model: MentorSchedule },
  { file: '../database/chats/chats.json', key: 'conversations', model: Conversation },
  { file: '../database/chats/chats.json', key: 'messages', model: Message }
];

async function migrate() {
  try {
    await mongoose.connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true });
    console.log('Connected to MongoDB Atlas for Migration.');

    for (const { file, key, model } of MIGRATION_MAP) {
      const filePath = path.join(__dirname, file);
      if (!fs.existsSync(filePath)) {
        console.warn(`Warning: File ${filePath} not found.`);
        continue;
      }
      
      const rawData = fs.readFileSync(filePath, 'utf-8');
      const db = JSON.parse(rawData);
      const items = db[key] || [];
      
      if (items.length > 0) {
        // Drop existing data to prevent duplicates during migration tests
        await model.deleteMany({});
        
        // Remove 'id' if it's there so Mongo can generate ObjectId, 
        // OR we can keep it. Since we want to use Mongo's ObjectIds, let's remove 'id' 
        // EXCEPT we have relational IDs (userId, mentorId). 
        // Actually, if we re-generate IDs, all relationships break! 
        // So we MUST retain the existing string/integer IDs as the _id!
        
        const preparedItems = items.map(item => {
          if (item.id) {
            item._id = item.id.toString(); // Use the existing JSON id as the MongoDB _id
            delete item.id;
          }
          return item;
        });

        await model.insertMany(preparedItems);
        console.log(`Migrated ${preparedItems.length} records into ${model.modelName}.`);
      }
    }
    
    console.log('Migration Completed Successfully!');
    process.exit(0);
  } catch (err) {
    console.error('Migration failed:', err);
    process.exit(1);
  }
}

migrate();
